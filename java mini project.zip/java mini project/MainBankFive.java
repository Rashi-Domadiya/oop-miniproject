
public class MainBankFive {

    public static void main(String[] args) {

        AccountFive[] accounts = {
            new SavingsAccountFive("AC0001", "Rahul", 10000, 2000),
            new CurrentAccountFive("AC0002", "Priya", 5000, 3000),
            new FixedDepositAccountFive("AC0003", "Amit", 20000)
        };

        System.out.println("===== ACCOUNT DETAILS =====");

        for (AccountFive account : accounts) {
            System.out.println(account);
            System.out.println("Interest Rate: "
                    + account.interestRate() + "%");

            // Pattern matching with instanceof
            if (account instanceof SavingsAccountFive savings) {
                System.out.println("Minimum Balance: Rs. "
                        + savings.getMinBalance());
            }

            System.out.println("----------------------------");
        }

        System.out.println("\n===== WITHDRAWAL TESTS =====");

        System.out.println("Savings withdraw Rs. 9000: "
                + accounts[0].withdraw(9000));

        System.out.println("Current withdraw Rs. 7000: "
                + accounts[1].withdraw(7000));

        System.out.println("Fixed Deposit withdraw Rs. 1000: "
                + accounts[2].withdraw(1000));

        System.out.println("\n===== UPDATED BALANCES =====");

        for (AccountFive account : accounts) {
            System.out.println(account.getOwnerName()
                    + ": Rs. " + account.getBalance());
        }
    }
}
