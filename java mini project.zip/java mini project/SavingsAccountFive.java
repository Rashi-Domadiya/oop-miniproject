
public class SavingsAccountFive extends AccountFive {

    private long minBalance;

    public SavingsAccountFive(String accountNumber, String ownerName,
                              long balance, long minBalance) {
        super(accountNumber, ownerName, balance);
        this.minBalance = minBalance;
    }

    @Override
    public double interestRate() {
        return 4.0;
    }

    @Override
    public boolean canWithdraw(long amount) {
        return amount > 0 && balance - amount >= minBalance;
    }

    public long getMinBalance() {
        return minBalance;
    }
}
