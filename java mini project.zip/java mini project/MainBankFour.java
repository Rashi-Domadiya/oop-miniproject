public class MainBankFour {

    public static void main(String[] args) {

        // Test mobile validation
        System.out.println("===== MOBILE VALIDATION =====");
        System.out.println(ValidatorFour.isValidMobile("9876543210"));
        System.out.println(ValidatorFour.isValidMobile("12345"));

        // Test email validation
        System.out.println("\n===== EMAIL VALIDATION =====");
        System.out.println(ValidatorFour.isValidEmail("user@example.com"));
        System.out.println(ValidatorFour.isValidEmail("user@"));

        // Test PAN validation
        System.out.println("\n===== PAN VALIDATION =====");
        System.out.println(ValidatorFour.isValidPan("ABCDE1234F"));
        System.out.println(ValidatorFour.isValidPan("ABC123"));

        // Test IFSC validation
        System.out.println("\n===== IFSC VALIDATION =====");
        System.out.println(ValidatorFour.isValidIfsc("SBIN0001234"));
        System.out.println(ValidatorFour.isValidIfsc("123INVALID"));

        // Parse a command
        System.out.println("\n===== COMMAND PARSER =====");

        try {
            CommandFour command =
                    CommandParserFour.parse("DEPOSIT AC0001 500");

            System.out.println("Type: " + command.type());
            System.out.println("Account Number: "
                    + command.accountNumber());
            System.out.println("Amount: " + command.amount());

        } catch (IllegalArgumentException e) {
            System.out.println("Error: " + e.getMessage());
        }

        // Build account statement
        System.out.println("\n===== ACCOUNT STATEMENT =====");

        AccountFour account =
                new AccountFour("AC0001", "Rahul", 5000);

        System.out.println(
                StatementFormatterFour.buildStatement(account));
    }
}