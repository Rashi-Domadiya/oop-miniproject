
public class MiniBankTwo {

    public static void main(String[] args) {

        Account[] accounts = {
            new Account("Rahul", 5000),
            new Account("Priya", 3000),
            new Account("Amit")
        };

        accounts[0].deposit(2000);
        accounts[0].withdraw(1000);

        accounts[1].deposit(1500);
        accounts[1].withdraw(500);

        accounts[2].deposit(4000);
        accounts[2].withdraw(1000);

        System.out.println("\n===== ACCOUNT DETAILS =====");

        for (Account account : accounts) {
            System.out.println("Account Number: "
                    + account.getAccountNumber());
            System.out.println("Owner: "
                    + account.getOwnerName());
            System.out.println("Balance: Rs. "
                    + account.getBalance());
            System.out.println("Active: "
                    + account.isActive());
            System.out.println("---------------------------");
        }
    }
}
