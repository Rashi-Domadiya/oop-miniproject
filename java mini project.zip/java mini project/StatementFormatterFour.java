public class StatementFormatterFour {

    public static String buildStatement(AccountFour account) {

        StringBuilder statement = new StringBuilder();

        statement.append("======= MINI BANK STATEMENT =======\n");
        statement.append("Account Number: ")
                .append(account.getAccountNumber()).append("\n");
        statement.append("Account Holder: ")
                .append(account.getOwnerName()).append("\n");
        statement.append("Balance: Rs. ")
                .append(account.getBalance()).append("\n");
        statement.append("===================================");

        return statement.toString();
    }
}