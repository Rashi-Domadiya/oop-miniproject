public record CommandFour(
        TransactionTypeFour type,
        String accountNumber,
        long amount) {
}