
public class MainBankThree {

    public static void main(String[] args) {

        // Create three accounts
        AccountThree account1 = new AccountThree("Rahul", 5000);
        AccountThree account2 = new AccountThree("Priya", 3000);
        AccountThree account3 = new AccountThree("Amit", 4000);

        // Print accounts using toString()
        System.out.println("===== ACCOUNT DETAILS =====");
        System.out.println(account1.toString());
        System.out.println(account2.toString());
        System.out.println(account3.toString());

        // Compare accounts using equals()
        System.out.println("\n===== EQUALS CHECK =====");
        System.out.println("Account 1 equals Account 2: "
                + account1.equals(account2));

        // Check object type using instanceof
        System.out.println("\n===== INSTANCEOF CHECK =====");
        Object obj = account1;

        if (obj instanceof AccountThree) {
            System.out.println("Object is an AccountThree");
        } else {
            System.out.println("Object is not an AccountThree");
        }

        // Create customer and address
        CustomerThree customer = new CustomerThree(
                "Rahul", "rahul@example.com", "9876543210");

        CustomerThree.Address address =
                new CustomerThree.Address(
                        "12 Main Road", "Jamnagar", "361001");

        customer.setAddress(address);

        System.out.println("\n===== CUSTOMER DETAILS =====");
        System.out.println(customer);
        System.out.println("Address: " + customer.getAddress());

        // Clone customer
        CustomerThree clonedCustomer = customer.clone();

        System.out.println("\n===== CLONED CUSTOMER =====");
        System.out.println(clonedCustomer);
        System.out.println("Original and clone are same object: "
                + (customer == clonedCustomer));
    }
}
