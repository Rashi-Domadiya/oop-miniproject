public class CommandParserFour {

    public static CommandFour parse(String line) {

        if (line == null) {
            throw new IllegalArgumentException(
                    "Command cannot be null");
        }

        String[] parts = line.trim().split("\\s+");

        if (parts.length != 3) {
            throw new IllegalArgumentException(
                    "Format: TYPE ACCOUNT_NUMBER AMOUNT");
        }

        try {
            TransactionTypeFour type =
                    TransactionTypeFour.valueOf(
                            parts[0].toUpperCase());

            String accountNumber = parts[1];
            long amount = Long.parseLong(parts[2]);

            if (!accountNumber.matches("AC\\d{4}")) {
                throw new IllegalArgumentException(
                        "Invalid account number");
            }

            if (amount <= 0) {
                throw new IllegalArgumentException(
                        "Amount must be positive");
            }

            return new CommandFour(
                    type, accountNumber, amount);

        } catch (NumberFormatException e) {
            throw new IllegalArgumentException(
                    "Amount must be a valid whole number");
        }
    }
}