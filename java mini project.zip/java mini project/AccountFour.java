public class AccountFour {

    private final String accountNumber;
    private String ownerName;
    private long balance;

    public AccountFour(
            String accountNumber,
            String ownerName,
            long balance) {
        this.accountNumber = accountNumber;
        this.ownerName = ownerName;
        this.balance = balance;
    }

    public String getAccountNumber() {
        return accountNumber;
    }

    public String getOwnerName() {
        return ownerName;
    }

    public long getBalance() {
        return balance;
    }
}