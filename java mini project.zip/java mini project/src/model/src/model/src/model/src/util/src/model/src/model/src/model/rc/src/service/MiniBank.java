
package service;

import model.Account;
import model.SavingsAccount;
import model.CurrentAccount;
import model.FixedDepositAccount;
import model.Premium;
import util.WithdrawRule;

import static java.lang.System.out;

public class MiniBank {

    public static void main(String[] args) {

        Account[] accounts = {
            new SavingsAccount("AC0001", "Rahul", 10000, 2000),
            new CurrentAccount("AC0002", "Priya", 5000, 3000),
            new FixedDepositAccount("AC0003", "Amit", 20000)
        };

        out.println("===== MINIBANK ACCOUNTS =====");

        for (Account account : accounts) {
            out.println(account);
            out.println("Interest Rate: "
                    + account.interestRate() + "%");
            out.println("Yearly Interest: Rs. "
                    + account.yearlyInterest());
            out.println();
        }

        // Anonymous class implementation
        WithdrawRule rule1 = new WithdrawRule() {
            @Override
            public boolean allow(Account account, long amount) {
                return account.canWithdraw(amount);
            }
        };

        // Lambda expression implementation
        WithdrawRule rule2 =
                (account, amount) -> account.canWithdraw(amount);

        out.println("===== WITHDRAW RULES =====");

        out.println("Anonymous class allows withdrawal: "
                + rule1.allow(accounts[0], 3000));

        out.println("Lambda allows withdrawal: "
                + rule2.allow(accounts[1], 7000));

        out.println("Fixed deposit allows withdrawal: "
                + rule2.allow(accounts[2], 1000));

        // Marker interface check
        out.println("\n===== PREMIUM CHECK =====");

        if (accounts[0] instanceof Premium) {
            out.println("Rahul has a Premium account.");
        }

        // Demonstrate deposit and withdrawal
        out.println("\n===== TRANSACTIONS =====");

        accounts[0].deposit(1000);
        out.println("After deposit: " + accounts[0].getBalance());

        boolean success = accounts[0].withdraw(2000);
        out.println("Withdrawal successful: " + success);
        out.println("Final balance: " + accounts[0].getBalance());
    }
}
