
import java.util.Scanner;

record BankInfo(String name, String branch) {
}

enum MenuOption {
    OPEN_ACCOUNT,
    DEPOSIT,
    WITHDRAW,
    TRANSFER,
    EXIT
}

public class MiniBank {

    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);

        // Display bank information
        BankInfo bank = new BankInfo("MiniBank", "Main Branch");

        System.out.println("================================");
        System.out.println("       " + bank.name());
        System.out.println("       Branch: " + bank.branch());
        System.out.println("================================");

        int choice;

        // Display menu until the user selects EXIT
        do {
            System.out.println("\n========== MAIN MENU ==========");
            System.out.println("1. Open Account");
            System.out.println("2. Deposit");
            System.out.println("3. Withdraw");
            System.out.println("4. Transfer");
            System.out.println("5. Exit");
            System.out.print("Enter your choice: ");

            // Validate numeric input
            while (!scanner.hasNextInt()) {
                System.out.println("Invalid input. Please enter a number.");
                scanner.next();
                System.out.print("Enter your choice: ");
            }

            choice = scanner.nextInt();

            if (choice < 1 || choice > 5) {
                System.out.println("Invalid choice. Please select 1-5.");
                continue;
            }

            // Handle menu selection using a switch expression
            String message = switch (choice) {
                case 1 -> MenuOption.OPEN_ACCOUNT
                        + " - to be implemented in a later lab";
                case 2 -> MenuOption.DEPOSIT
                        + " - to be implemented in a later lab";
                case 3 -> MenuOption.WITHDRAW
                        + " - to be implemented in a later lab";
                case 4 -> MenuOption.TRANSFER
                        + " - to be implemented in a later lab";
                case 5 -> MenuOption.EXIT + " selected";
                default -> "Invalid choice";
            };

            if (choice != 5) {
                System.out.println(message);
            }

        } while (choice != 5);

        System.out.println("\nThank you for using MiniBank!");
        System.out.println("Goodbye!");

        scanner.close();
    }
}
