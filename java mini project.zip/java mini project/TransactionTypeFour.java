public enum TransactionTypeFour {
    DEPOSIT,
    WITHDRAW,
    TRANSFER
}